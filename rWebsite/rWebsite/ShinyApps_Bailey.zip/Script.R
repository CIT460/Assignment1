install.packages(c("shiny",'ggplot2', 'dplyr'), quiet = TRUE)

library(shiny)
library(ggplot2)

runApp("shinyapp_p1")
runApp("shinyapp_p2")